/**
 * Percentile layer for athlete tracking.
 * Uses existing payload builders; computes percentile rank for each metric vs all other athletes.
 */

import { definePopulation } from "@/lib/percentiles/populations";
import { prisma } from "@/lib/db/prisma";
import { buildPitchingPayload } from "@/lib/octane/pitchingPayload";
import { buildHittingPayload } from "@/lib/octane/hittingPayload";
import { buildMobilityPayload } from "@/lib/octane/mobilityPayload";
import { buildAthleticScreenPayload } from "@/lib/octane/athleticScreenPayload";
import { buildArmActionPayload } from "@/lib/octane/armActionPayload";
import {
  buildProteusPitcherPayload,
  buildProteusHitterPayload,
} from "@/lib/octane/proteusPayload";
import {
  computePercentileRank,
  metricKey,
} from "@/lib/athlete-tracking/percentile";
import type {
  DomainId,
  DomainWithMetrics,
  MetricWithPercentile,
} from "@/lib/athlete-tracking/types";

const POPULATION_LIMIT = 150;

type PayloadMetric = {
  category: string;
  name: string;
  value: number | null;
  valueUnit: string;
  orientation: string | null;
  mobilityMetricKind?: "GROUP" | "COMPONENT";
  mobilityGroup?: string;
  mobilityDisplayLabel?: string;
  mobilityOutOf?: number | null;
};

type PopulationByKey = Record<string, Array<{ athleteUuid: string; value: number }>>;

function attachPercentiles(
  metrics: PayloadMetric[],
  populationByKey: PopulationByKey,
  athleteUuid: string
): MetricWithPercentile[] {
  return metrics.map((m) => {
    const key = metricKey(m.category, m.name);
    const pop = populationByKey[key];
    let percentile: number | null = null;
    if (m.value !== null && Number.isFinite(m.value) && pop && pop.length > 0) {
      const values = pop.map((p) => p.value);
      percentile = computePercentileRank(
        m.value,
        values,
        m.orientation as "HIGHER_IS_BETTER" | "LOWER_IS_BETTER" | null
      );
    }
    return {
      ...m,
      percentile,
    };
  });
}

async function getAthleteUuidsWithPitching(): Promise<string[]> {
  const [fromTrials, fromKinematics] = await Promise.all([
    prisma.f_pitching_trials.findMany({
      select: { athlete_uuid: true },
      distinct: ["athlete_uuid"],
      take: POPULATION_LIMIT,
    }),
    prisma.f_kinematics_pitching.findMany({
      select: { athlete_uuid: true },
      distinct: ["athlete_uuid"],
      take: POPULATION_LIMIT,
    }),
  ]);
  const set = new Set(fromTrials.map((r) => r.athlete_uuid));
  fromKinematics.forEach((r) => set.add(r.athlete_uuid));
  return Array.from(set);
}

async function getPopulationPayloads(
  uuids: string[],
  builder: (uuid: string) => Promise<{ athleteUuid: string; metrics: PayloadMetric[] }>
): Promise<PopulationByKey> {
  const byKey: PopulationByKey = {};
  const batchSize = 4;
  for (let i = 0; i < uuids.length; i += batchSize) {
    const batch = uuids.slice(i, i + batchSize);
    const results = await Promise.allSettled(
      batch.map((uuid) => builder(uuid))
    );
    for (const result of results) {
      if (result.status !== "fulfilled") throw new Error("Population member build failed", { cause: result.reason });
      const { athleteUuid, metrics } = result.value;
      for (const m of metrics) {
        if (m.value === null || !Number.isFinite(m.value)) continue;
        const key = metricKey(m.category, m.name);
        if (!byKey[key]) byKey[key] = [];
        byKey[key]!.push({ athleteUuid, value: m.value });
      }
    }
  }
  return byKey;
}

export type DomainResult = {
  metrics: MetricWithPercentile[];
  sessionDate?: string | null;
};

// ---------------------------------------------------------------------------
// Persistent population readers. Expensive builders run only in the worker.
// Cohort selection and ranking conventions are preserved.
// ---------------------------------------------------------------------------

const getCachedPitchingPopulation = definePopulation(
  "population-pitching",
  async () => {
    const uuids = await getAthleteUuidsWithPitching();
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildPitchingPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedHittingPopulation = definePopulation(
  "population-hitting",
  async () => {
    const uuids = await getAthleteUuidsWithHitting();
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildHittingPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedMobilityPopulation = definePopulation(
  "population-mobility",
  async () => {
    const uuids = await getAthleteUuidsWithMobility();
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildMobilityPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedAthleticScreenPopulation = definePopulation(
  "population-athletic-screen",
  async () => {
    const uuids = await getAthleteUuidsWithAthleticScreen();
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildAthleticScreenPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedAthleticScreenPopulationFemale = definePopulation(
  "population-athletic-screen-female",
  async () => {
    const rows = await prisma.$queryRaw<Array<{ athlete_uuid: string }>>`
      SELECT DISTINCT v.athlete_uuid
        FROM public.v_athletic_screen_cmj v
        JOIN analytics.d_athletes d ON d.athlete_uuid = v.athlete_uuid
       WHERE d.gender = 'Female'
       LIMIT ${POPULATION_LIMIT}`;
    const uuids = rows.map((r) => r.athlete_uuid);
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildAthleticScreenPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedArmActionPopulation = definePopulation(
  "population-arm-action",
  async () => {
    const uuids = await getAthleteUuidsWithArmAction();
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildArmActionPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedProteusPitcherPopulation = definePopulation(
  "population-proteus-pitcher",
  async () => {
    const uuids = await prisma.f_proteus.findMany({
      where: {
        position: "Pitcher",
        OR: [
          { movement: { contains: "Shot Put", mode: "insensitive" } },
          { movement: { contains: "D2 Extension", mode: "insensitive" } },
        ],
      },
      select: { athlete_uuid: true },
      distinct: ["athlete_uuid"],
      take: POPULATION_LIMIT,
    }).then((r) => r.map((x) => x.athlete_uuid));
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildProteusPitcherPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

const getCachedProteusHitterPopulation = definePopulation(
  "population-proteus-hitter",
  async () => {
    const uuids = await prisma.f_proteus.findMany({
      where: {
        AND: [
          { OR: [{ position: null }, { position: { not: "Pitcher" } }] },
          {
            OR: [
              { movement: { contains: "Shot Put", mode: "insensitive" } },
              { movement: { equals: "Straight Arm Trunk Rotation", mode: "insensitive" } },
            ],
          },
        ],
      },
      select: { athlete_uuid: true },
      distinct: ["athlete_uuid"],
      take: POPULATION_LIMIT,
    }).then((r) => r.map((x) => x.athlete_uuid));
    return getPopulationPayloads(uuids, async (uuid) => {
      const p = await buildProteusHitterPayload(uuid);
      return { athleteUuid: p.athleteUuid, metrics: p.metrics };
    });
  },
  () => ({} as PopulationByKey),
);

export async function getPitchingWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, population] = await Promise.all([
      buildPitchingPayload(athleteUuid, sessionDate),
      getCachedPitchingPopulation(),
    ]);
    const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    return null;
  }
}

async function getAthleteUuidsWithHitting(): Promise<string[]> {
  const rows = await prisma.f_kinematics_hitting.findMany({
    select: { athlete_uuid: true },
    distinct: ["athlete_uuid"],
    take: POPULATION_LIMIT,
  });
  return rows.map((r) => r.athlete_uuid);
}

export async function getHittingWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, population] = await Promise.all([
      buildHittingPayload(athleteUuid, sessionDate),
      getCachedHittingPopulation(),
    ]);
    const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    return null;
  }
}

async function getAthleteUuidsWithMobility(): Promise<string[]> {
  const rows = await prisma.f_mobility.findMany({
    select: { athlete_uuid: true },
    distinct: ["athlete_uuid"],
    take: POPULATION_LIMIT,
  });
  return rows.map((r) => r.athlete_uuid);
}

export async function getMobilityWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, population] = await Promise.all([
      buildMobilityPayload(athleteUuid, sessionDate),
      getCachedMobilityPopulation(),
    ]);
    const withPercentiles = attachPercentiles(payload.metrics, population, athleteUuid);
    const metrics = withPercentiles.map((m) => ({
      ...m,
      // All GROUP scores are 0-100; set max=100 so metricsToRadarData renders correctly
      max: m.mobilityMetricKind === "GROUP" ? 100 : null,
    }));
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    return null;
  }
}

async function getAthleteUuidsWithAthleticScreen(): Promise<string[]> {
  const rows = await prisma.v_athletic_screen_cmj.findMany({
    select: { athlete_uuid: true },
    distinct: ["athlete_uuid"],
    take: POPULATION_LIMIT,
  });
  return rows.map((r) => r.athlete_uuid);
}

export async function getAthleticScreenWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, athlete] = await Promise.all([
      buildAthleticScreenPayload(athleteUuid, sessionDate),
      prisma.d_athletes.findUnique({
        where: { athlete_uuid: athleteUuid },
        select: { gender: true },
      }),
    ]);
    const isFemale = athlete?.gender === "Female";
    const population = await (isFemale
      ? getCachedAthleticScreenPopulationFemale()
      : getCachedAthleticScreenPopulation());
    const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    return null;
  }
}

async function getAthleteUuidsWithArmAction(): Promise<string[]> {
  const rows = await prisma.f_arm_action.findMany({
    select: { athlete_uuid: true },
    distinct: ["athlete_uuid"],
    take: POPULATION_LIMIT,
  });
  return rows.map((r) => r.athlete_uuid);
}

export async function getArmActionWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, population] = await Promise.all([
      buildArmActionPayload(athleteUuid, sessionDate),
      getCachedArmActionPopulation(),
    ]);
    const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    return null;
  }
}

/** Proteus: try pitcher first, then hitter; use matching population. */
export async function getProteusWithPercentiles(
  athleteUuid: string,
  sessionDate?: string
): Promise<DomainResult | null> {
  try {
    const [payload, population] = await Promise.all([
      buildProteusPitcherPayload(athleteUuid, sessionDate),
      getCachedProteusPitcherPopulation(),
    ]);
    const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
    return { metrics, sessionDate: payload.sessionDate ?? null };
  } catch {
    try {
      const [payload, population] = await Promise.all([
        buildProteusHitterPayload(athleteUuid, sessionDate),
        getCachedProteusHitterPopulation(),
      ]);
      const metrics = attachPercentiles(payload.metrics, population, athleteUuid);
      return { metrics, sessionDate: payload.sessionDate ?? null };
    } catch {
      return null;
    }
  }
}

const DOMAIN_LABELS: Record<DomainId, string> = {
  pitching: "Pitching",
  hitting: "Hitting",
  mobility: "Mobility",
  athleticScreen: "Athletic Screen",
  armAction: "Arm Action",
  proteus: "Proteus",
};

type ReportCounts = {
  armAction: number;
  athleticScreen: number;
  mobility: number;
  proSup: number;
  proteus: number;
  readinessScreen: number;
  kinematicsPitching: number;
  kinematicsHitting: number;
  curveballTest: number;
};

const DOMAIN_COUNT_KEYS: Record<DomainId, keyof ReportCounts> = {
  pitching: "kinematicsPitching",
  hitting: "kinematicsHitting",
  mobility: "mobility",
  athleticScreen: "athleticScreen",
  armAction: "armAction",
  proteus: "proteus",
};

export async function buildDomainsWithPercentiles(
  athleteUuid: string,
  counts: ReportCounts,
  sessionDates?: Partial<Record<DomainId, string>>,
  requestedDomains?: readonly DomainId[]
): Promise<DomainWithMetrics[]> {
  const domainBuilders: Array<{
    domainId: DomainId;
    build: () => Promise<DomainResult | null>;
  }> = [
    {
      domainId: "pitching",
      build: () => getPitchingWithPercentiles(athleteUuid, sessionDates?.pitching),
    },
    {
      domainId: "hitting",
      build: () => getHittingWithPercentiles(athleteUuid, sessionDates?.hitting),
    },
    {
      domainId: "mobility",
      build: () => getMobilityWithPercentiles(athleteUuid, sessionDates?.mobility),
    },
    {
      domainId: "athleticScreen",
      build: () => getAthleticScreenWithPercentiles(athleteUuid, sessionDates?.athleticScreen),
    },
    {
      domainId: "armAction",
      build: () => getArmActionWithPercentiles(athleteUuid, sessionDates?.armAction),
    },
    {
      domainId: "proteus",
      build: () => getProteusWithPercentiles(athleteUuid, sessionDates?.proteus),
    },
  ];

  const eligible = domainBuilders.filter(
    ({ domainId }) => counts[DOMAIN_COUNT_KEYS[domainId]] > 0 && (!requestedDomains || requestedDomains.includes(domainId))
  );

  const settled = await Promise.allSettled(
    eligible.map(({ build }) => build())
  );

  const results: DomainWithMetrics[] = [];
  for (let i = 0; i < eligible.length; i++) {
    const { domainId } = eligible[i]!;
    const outcome = settled[i]!;
    if (outcome.status !== "fulfilled") continue;
    const result = outcome.value;
    if (result && result.metrics.length > 0) {
      results.push({
        domainId,
        label: DOMAIN_LABELS[domainId],
        metrics: result.metrics,
        sessionDate: result.sessionDate ?? undefined,
      });
    }
  }
  return results;
}
