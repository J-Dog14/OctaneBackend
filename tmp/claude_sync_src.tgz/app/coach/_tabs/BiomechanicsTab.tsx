"use client";

import { useState } from "react";
import { SegmentedControl, Stack } from "@mantine/core";
import type { CoachAthleteSummary } from "@/lib/coach/summary";
import { DomainSwitcher } from "../_components/DomainWorkspace";
import { BiomechReport } from "../_reports/BiomechReport";
import { PitchSyncView } from "../_components/PitchSyncView";
import { LoadState, pickDomains, useTracking } from "./shared";

/**
 * Pitching 3D opens on the 8-cylinder report (same read as the
 * biomech-pitching-breakdown PDF). "Mechanics + Flight" pairs each 3D trial with
 * its TrackMan pitch (only when a capture has been paired). "Metrics explorer" keeps
 * the percentile tables, timelines and comparisons for pitching and arm action
 * (hitting has its own tab).
 */
export function BiomechanicsTab({ athleteUuid, summary }: { athleteUuid: string; summary: CoachAthleteSummary }) {
  const hasPitching = summary.trackingDomains.includes("pitching");
  const hasSync = hasPitching && (summary.pitchSyncDates?.length ?? 0) > 0;
  const [view, setView] = useState<"report" | "sync" | "explorer">(hasPitching ? "report" : "explorer");
  const { data, error, isLoading } = useTracking(athleteUuid);

  return (
    <Stack gap="md">
      {hasPitching && (
        <SegmentedControl
          w="fit-content"
          value={view}
          onChange={(v) => setView(v as "report" | "sync" | "explorer")}
          data={[
            { value: "report", label: "Pitching report" },
            ...(hasSync ? [{ value: "sync", label: "Mechanics + Flight" }] : []),
            { value: "explorer", label: "Metrics explorer" },
          ]}
        />
      )}
      {view === "report" && hasPitching ? (
        <BiomechReport athleteUuid={athleteUuid} />
      ) : view === "sync" && hasSync ? (
        <PitchSyncView athleteUuid={athleteUuid} />
      ) : !data ? (
        <LoadState isLoading={isLoading} error={error} />
      ) : (
        <DomainSwitcher
          athleteUuid={athleteUuid}
          domains={pickDomains(data, ["pitching", "armAction"])}
          datesByDomain={summary.trackingDates}
          emptyText="No biomechanics captures for this athlete yet."
        />
      )}
    </Stack>
  );
}
