"use client";

/**
 * Biomechanics → "Mechanics + Flight": each 3D trial beside the TrackMan pitch it
 * was thrown as (paired by uais/python/trackman/match_3d.py). Coach hub only.
 */

import { useMemo, useState } from "react";
import useSWR from "swr";
import { Alert, Badge, Group, Loader, ScrollArea, SegmentedControl, Select, Stack, Table, Text, Tooltip } from "@mantine/core";
import { CartesianGrid, Cell, ResponsiveContainer, Scatter, ScatterChart, Tooltip as RTooltip, XAxis, YAxis } from "recharts";
import { PITCH_COLORS, PITCH_LABELS, type PitchCode } from "@/lib/pitch-intel/pitch-types";
import type { LinkConfidence, MetricDef, PitchSyncData, SyncPitch } from "@/lib/coach/pitchSync";
import { PITCH_CATEGORY_LABEL, PITCH_CATEGORY_SHORT } from "@/lib/coach/biomech/pitchCategory";
import { fmt, fmtDate, swrOpts } from "./fetcher";
import { PitchDot } from "./pitching";

const AXIS_TICK = { fill: "rgba(255,255,255,0.5)", fontSize: 11 };
const GRID = "rgba(255,255,255,0.07)";
const TOOLTIP_STYLE = {
  background: "var(--bg-secondary)",
  border: "1px solid var(--border)",
  borderRadius: 6,
  fontSize: "0.78rem",
  color: "var(--text-primary)",
  padding: "6px 10px",
};

/** Same ids as pitchSync.ts MOVEMENT_IDS (kept here so the client bundle doesn't import server code). */
const MOVEMENT_IDS = new Set(["ivb", "hbArm", "spinAxis", "spinEff", "gyro", "vaa", "haa"]);

/** Flight columns shown in the table (all flight metrics stay available on the chart). */
const TABLE_FLIGHT = ["velo", "spin", "ivb", "hbArm", "spinAxis", "spinEff", "relHeight", "extension"];

const CONFIDENCE: Record<LinkConfidence, { color: string; label: string; help: string }> = {
  exact: { color: "teal", label: "exact", help: "Velo, timing and pitch type all line up" },
  probable: { color: "blue", label: "probable", help: "Lines up, with one small mismatch (velo off by ≤ 0.1, or no 3D velo)" },
  review: { color: "orange", label: "review", help: "Paired, but check it: velo, timing or type doesn't fully agree" },
  manual: { color: "gray", label: "manual", help: "Paired by hand" },
};

const MECH_GROUPS = ["Forearm", "Arm", "Speed", "Body"] as const;

function value(p: SyncPitch, id: string): number | null {
  if (id in p.mech) return p.mech[id] ?? null;
  return p.flight[id] ?? null;
}

function mean(xs: Array<number | null>): number | null {
  const v = xs.filter((x): x is number => x != null && Number.isFinite(x));
  return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
}

function MetricCell({ v, def }: { v: number | null; def: MetricDef }) {
  return <Table.Td ta="right">{fmt(v, def.digits)}</Table.Td>;
}

export function PitchSyncView({ athleteUuid }: { athleteUuid: string }) {
  const [date, setDate] = useState<string | null>(null);
  const [group, setGroup] = useState<(typeof MECH_GROUPS)[number]>("Forearm");
  const [hidden, setHidden] = useState<Set<PitchCode>>(new Set());
  const [xId, setXId] = useState("proSupRelease");
  const [yId, setYId] = useState("spinAxis");

  const key = `/api/coach/athletes/${encodeURIComponent(athleteUuid)}/pitch-sync${date ? `?date=${date}` : ""}`;
  const { data: d, error, isLoading } = useSWR<PitchSyncData>(key, { ...swrOpts, keepPreviousData: true });

  const rows = useMemo(() => {
    if (!d) return [];
    return [...d.pitches].sort((a, b) => (a.tm?.pitchNo ?? 1e9) - (b.tm?.pitchNo ?? 1e9) || a.captureOrder - b.captureOrder);
  }, [d]);
  const types = useMemo(() => {
    const seen: PitchCode[] = [];
    for (const r of rows) if (r.tm && !seen.includes(r.tm.code)) seen.push(r.tm.code);
    return seen;
  }, [rows]);

  if (isLoading && !d) return <Loader size="sm" />;
  if (error && !d) return <Alert color="red">{error.message}</Alert>;
  if (!d) return null;

  const flightDefs = new Map(d.flightMetrics.map((m) => [m.id, m]));
  const mechDefs = new Map(d.mechMetrics.map((m) => [m.id, m]));
  const tableFlight = TABLE_FLIGHT.map((id) => flightDefs.get(id)!).filter(Boolean);
  const tableMech = d.mechMetrics.filter((m) => m.group === group);
  const visible = rows.filter((r) => !r.tm || !hidden.has(r.tm.code));
  const paired = rows.filter((r) => r.tm);
  const unpaired = rows.length - paired.length;
  const toggle = (c: PitchCode) =>
    setHidden((h) => {
      const n = new Set(h);
      if (n.has(c)) n.delete(c);
      else n.add(c);
      return n;
    });

  // Chart: paired pitches with both values; velo-only TrackMan reads drop out of movement/spin metrics.
  const xDef = mechDefs.get(xId) ?? flightDefs.get(xId);
  const yDef = flightDefs.get(yId) ?? mechDefs.get(yId);
  const chartPts = visible
    .filter((r) => r.tm)
    .map((r) => ({ x: value(r, xId), y: value(r, yId), r }))
    .filter((p): p is { x: number; y: number; r: SyncPitch } => p.x != null && p.y != null);
  const veloOnlyDropped = MOVEMENT_IDS.has(yId) ? visible.filter((r) => r.tm && !r.tm.hasMovement).length : 0;

  const typeMeans = types
    .filter((c) => !hidden.has(c))
    .map((c) => {
      const rs = paired.filter((r) => r.tm!.code === c);
      return { code: c, n: rs.length, rows: rs };
    });

  const metricOptions = (defs: MetricDef[]) => {
    const groups = [...new Set(defs.map((m) => m.group))];
    return groups.map((g) => ({ group: g, items: defs.filter((m) => m.group === g).map((m) => ({ value: m.id, label: `${m.label}${m.unit ? ` (${m.unit})` : ""}` })) }));
  };

  return (
    <Stack gap="md">
      <Group justify="space-between" align="flex-start">
        <div>
          <Text size="sm" c="dimmed">
            Each 3D trial next to the TrackMan pitch it was thrown as. {paired.length} of {rows.length} trials paired
            {d.tmPitchCount ? ` · ${d.tmPitchCount} live TrackMan pitches that day` : ""}
            {d.clockOffsetS != null ? ` · clocks ${Math.abs(Math.round(d.clockOffsetS))} s apart` : ""}
            {d.throws ? ` · ${d.throws === "L" ? "LHP" : "RHP"}` : ""}.
          </Text>
          <Text size="xs" c="dimmed">
            TM # = order thrown in the TrackMan session. Trial = 3D trial number within its pitch category. Breaking ball, off speed and untyped captures
            are coach hub only.
          </Text>
        </div>
        <Group gap="xs">
          {isLoading && <Loader size="xs" />}
          <Select
            size="xs"
            w={190}
            data={d.sessions.map((s) => ({ value: s, label: `Capture ${fmtDate(s)}` }))}
            value={d.sessionDate}
            onChange={(s) => s && setDate(s)}
            allowDeselect={false}
          />
        </Group>
      </Group>

      {types.length > 1 && (
        <Group gap={6}>
          {types.map((c) => (
            <Badge
              key={c}
              variant={hidden.has(c) ? "outline" : "light"}
              color="gray"
              style={{ cursor: "pointer", opacity: hidden.has(c) ? 0.5 : 1, textTransform: "none" }}
              onClick={() => toggle(c)}
              leftSection={<PitchDot code={c} />}
            >
              {PITCH_LABELS[c]} ({paired.filter((r) => r.tm!.code === c).length})
            </Badge>
          ))}
        </Group>
      )}

      {/* PAIRED PITCH TABLE */}
      <div>
        <Group justify="space-between" mb={6}>
          <Text fw={600}>Pitch by pitch</Text>
          <SegmentedControl size="xs" value={group} onChange={(g) => setGroup(g as (typeof MECH_GROUPS)[number])} data={[...MECH_GROUPS]} />
        </Group>
        <ScrollArea>
          <Table fz="sm" verticalSpacing={5} highlightOnHover withColumnBorders={false} style={{ whiteSpace: "nowrap" }}>
            <Table.Thead>
              <Table.Tr>
                <Table.Th ta="right">TM #</Table.Th>
                <Table.Th>Pitch</Table.Th>
                <Table.Th>3D trial</Table.Th>
                <Table.Th>Pair</Table.Th>
                {tableFlight.map((m) => (
                  <Table.Th key={m.id} ta="right">
                    {m.label}
                    {m.unit ? <Text span size="xs" c="dimmed"> {m.unit}</Text> : null}
                  </Table.Th>
                ))}
                {tableMech.map((m) => (
                  <Table.Th key={m.id} ta="right" style={{ borderLeft: m === tableMech[0] ? "1px solid var(--border)" : undefined }}>
                    <Tooltip label={m.help ?? m.label} disabled={!m.help} withArrow>
                      <span>
                        {m.label}
                        {m.unit ? <Text span size="xs" c="dimmed"> {m.unit}</Text> : null}
                      </span>
                    </Tooltip>
                  </Table.Th>
                ))}
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {visible.map((r) => {
                const c = r.tm ? CONFIDENCE[r.tm.confidence] : null;
                return (
                  <Table.Tr key={`${r.category}:${r.trialIndex}`} style={{ opacity: r.tm?.confidence === "review" ? 0.75 : 1 }}>
                    <Table.Td ta="right">{r.tm?.pitchNo ?? "—"}</Table.Td>
                    <Table.Td>
                      {r.tm ? (
                        <>
                          <PitchDot code={r.tm.code} />
                          {PITCH_LABELS[r.tm.code]}
                          {r.tm.tilt ? <Text span size="xs" c="dimmed"> · {r.tm.tilt}</Text> : null}
                        </>
                      ) : (
                        <Text span size="sm" c="dimmed">No TrackMan pitch</Text>
                      )}
                    </Table.Td>
                    <Table.Td>
                      <Tooltip label={r.ownerFilename ?? ""} disabled={!r.ownerFilename} withArrow>
                        <span>
                          {PITCH_CATEGORY_SHORT[r.category]} #{r.trialIndex}
                          {r.category !== "fastball" && <Text span size="xs" c="dimmed"> {PITCH_CATEGORY_LABEL[r.category].one.toLowerCase()}</Text>}
                        </span>
                      </Tooltip>
                    </Table.Td>
                    <Table.Td>
                      {c && r.tm && (
                        <Tooltip
                          multiline
                          w={260}
                          withArrow
                          label={`${c.help}${r.tm.residualS != null ? ` · timing ${r.tm.residualS >= 0 ? "+" : ""}${r.tm.residualS.toFixed(0)} s` : ""}${r.tm.notes ? ` · ${r.tm.notes}` : ""}`}
                        >
                          <Badge size="xs" variant="light" color={c.color}>
                            {c.label}
                          </Badge>
                        </Tooltip>
                      )}
                    </Table.Td>
                    {tableFlight.map((m) => (
                      <MetricCell key={m.id} v={r.flight[m.id] ?? null} def={m} />
                    ))}
                    {tableMech.map((m) => (
                      <Table.Td key={m.id} ta="right" style={{ borderLeft: m === tableMech[0] ? "1px solid var(--border)" : undefined }}>
                        {fmt(r.mech[m.id] ?? null, m.digits)}
                      </Table.Td>
                    ))}
                  </Table.Tr>
                );
              })}
            </Table.Tbody>
            {typeMeans.length > 0 && (
              <Table.Tfoot>
                {typeMeans.map((t) => (
                  <Table.Tr key={t.code} style={{ fontWeight: 600, borderTop: "1px solid var(--border)" }}>
                    <Table.Td />
                    <Table.Td>
                      <PitchDot code={t.code} />
                      {PITCH_LABELS[t.code]} avg
                    </Table.Td>
                    <Table.Td>
                      <Text span size="xs" c="dimmed">n={t.n}</Text>
                    </Table.Td>
                    <Table.Td />
                    {tableFlight.map((m) => (
                      <MetricCell key={m.id} v={mean(t.rows.map((r) => r.flight[m.id] ?? null))} def={m} />
                    ))}
                    {tableMech.map((m) => (
                      <Table.Td key={m.id} ta="right" style={{ borderLeft: m === tableMech[0] ? "1px solid var(--border)" : undefined }}>
                        {fmt(mean(t.rows.map((r) => r.mech[m.id] ?? null)), m.digits)}
                      </Table.Td>
                    ))}
                  </Table.Tr>
                ))}
              </Table.Tfoot>
            )}
          </Table>
        </ScrollArea>
        {unpaired > 0 && (
          <Text size="xs" c="dimmed" mt={4}>
            {unpaired} 3D trial{unpaired === 1 ? " has" : "s have"} no TrackMan pitch: no ball flight for {unpaired === 1 ? "it" : "them"}.
          </Text>
        )}
      </div>

      {/* MECHANICS vs BALL FLIGHT */}
      <div>
        <Group justify="space-between" mb={6} align="flex-end">
          <Text fw={600}>Mechanics vs ball flight</Text>
          <Group gap="xs">
            <Select size="xs" w={260} label="Mechanics (x)" data={metricOptions(d.mechMetrics)} value={xId} onChange={(v) => v && setXId(v)} allowDeselect={false} searchable />
            <Select size="xs" w={230} label="Ball flight (y)" data={metricOptions(d.flightMetrics)} value={yId} onChange={(v) => v && setYId(v)} allowDeselect={false} searchable />
          </Group>
        </Group>
        {chartPts.length < 2 ? (
          <Text size="sm" c="dimmed">Not enough paired pitches with both values to plot.</Text>
        ) : (
          <ResponsiveContainer width="100%" height={340}>
            <ScatterChart margin={{ top: 10, right: 20, bottom: 28, left: 6 }}>
              <CartesianGrid stroke={GRID} />
              <XAxis
                type="number"
                dataKey="x"
                domain={["auto", "auto"]}
                tick={AXIS_TICK}
                tickLine={false}
                axisLine={{ stroke: "rgba(255,255,255,0.12)" }}
                label={{ value: `${xDef?.label ?? xId}${xDef?.unit ? ` (${xDef.unit})` : ""}`, position: "insideBottom", offset: -14, fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
              />
              <YAxis
                type="number"
                dataKey="y"
                domain={["auto", "auto"]}
                tick={AXIS_TICK}
                tickLine={false}
                axisLine={false}
                width={48}
                label={{ value: `${yDef?.label ?? yId}${yDef?.unit ? ` (${yDef.unit})` : ""}`, angle: -90, position: "insideLeft", offset: 4, fill: "rgba(255,255,255,0.5)", fontSize: 11 }}
              />
              <RTooltip
                cursor={{ strokeDasharray: "3 3", stroke: "rgba(255,255,255,0.2)" }}
                content={({ payload }) => {
                  const p = payload?.[0]?.payload as { x: number; y: number; r: SyncPitch } | undefined;
                  if (!p || !p.r.tm) return null;
                  return (
                    <div style={TOOLTIP_STYLE}>
                      <div style={{ fontWeight: 600 }}>
                        <PitchDot code={p.r.tm.code} />
                        TM #{p.r.tm.pitchNo ?? "—"} · {PITCH_LABELS[p.r.tm.code]} · {PITCH_CATEGORY_SHORT[p.r.category]} #{p.r.trialIndex}
                      </div>
                      <div>
                        {xDef?.label}: {fmt(p.x, xDef?.digits ?? 1)} {xDef?.unit}
                      </div>
                      <div>
                        {yDef?.label}: {fmt(p.y, yDef?.digits ?? 1)} {yDef?.unit}
                      </div>
                      <div style={{ opacity: 0.7 }}>{fmt(p.r.flight.velo ?? null)} mph</div>
                    </div>
                  );
                }}
              />
              <Scatter data={chartPts} isAnimationActive={false}>
                {chartPts.map((p, i) => (
                  <Cell key={i} fill={PITCH_COLORS[p.r.tm!.code]} stroke="var(--bg-secondary)" strokeWidth={2} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        )}
        <Text size="xs" c="dimmed">
          {xDef?.help ? `${xDef.label}: ${xDef.help}. ` : ""}
          {veloOnlyDropped > 0
            ? `${veloOnlyDropped} pitch${veloOnlyDropped === 1 ? "" : "es"} left out: TrackMan only read velo, spin and release on ${veloOnlyDropped === 1 ? "it" : "them"}.`
            : ""}
        </Text>
      </div>
    </Stack>
  );
}
